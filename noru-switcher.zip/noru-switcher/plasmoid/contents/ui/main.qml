import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root
    preferredRepresentation: compactRepresentation
    Plasmoid.icon: "window-duplicate"
    toolTipMainText: i18n("Task Switcher")
    toolTipSubText: i18n("Show open windows")

    readonly property var shortcutNames: ["Walk Through Windows", "Overview", "Grid View"]

    P5Support.DataSource {
        id: exec
        engine: "executable"
        connectedSources: []
        onNewData: (source, data) => disconnectSource(source)
        function run(cmd) { connectSource(cmd) }
    }

    // Asks KWin to run one of its own global shortcut actions
    function trigger() {
        const name = shortcutNames[Plasmoid.configuration.action] || shortcutNames[0]
        exec.run("dbus-send --session --type=method_call --dest=org.kde.kglobalaccel " +
                 "/component/kwin org.kde.kglobalaccel.Component.invokeShortcut string:'" + name + "'")
    }

    // Also fires when a keyboard shortcut is assigned to the widget
    Connections {
        target: Plasmoid
        function onActivated() { root.trigger() }
    }

    compactRepresentation: MouseArea {
        id: btn
        hoverEnabled: true
        activeFocusOnTab: true
        Layout.minimumWidth: Kirigami.Units.iconSizes.medium
        Layout.minimumHeight: Kirigami.Units.iconSizes.medium
        onClicked: root.trigger()

        Kirigami.Icon {
            anchors.fill: parent
            anchors.margins: Math.round(Math.min(parent.width, parent.height) * 0.1)
            source: Qt.resolvedUrl("../icons/noru-switcher.svg")
            active: btn.containsMouse
        }
    }
}
