import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami
import org.kcmutils as KCM

KCM.SimpleKCM {
    property alias cfg_action: actionBox.currentIndex

    Kirigami.FormLayout {
        QQC2.ComboBox {
            id: actionBox
            Kirigami.FormData.label: i18n("Button opens:")
            model: [
                i18n("Task Switcher (your configured Alt+Tab switcher)"),
                i18n("Overview"),
                i18n("Grid View")
            ]
        }
        QQC2.Label {
            Kirigami.FormData.label: i18n("Tip:")
            Layout.maximumWidth: Kirigami.Units.gridUnit * 22
            wrapMode: Text.Wrap
            opacity: 0.7
            text: i18n("If the task switcher closes immediately, choose Overview instead.")
        }
    }
}
