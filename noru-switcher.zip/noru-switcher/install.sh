#!/usr/bin/env bash
# Noru Task Switcher button: KDE Plasma 6, user-level
set -euo pipefail
cd "$(dirname "$0")"
command -v kpackagetool6 >/dev/null || { echo "kpackagetool6 not found (Plasma 6 required)"; exit 1; }
ID=org.noru.switcher

case "${1:-install}" in
  install)
    kpackagetool6 --type Plasma/Applet --upgrade ./plasmoid 2>/dev/null || kpackagetool6 --type Plasma/Applet --install ./plasmoid
    echo "Installed. Right-click the panel -> Add Widgets -> Noru Task Switcher"
    echo "Or run: $0 add-to-panel"
    ;;
  add-to-panel)
    # Adds the button to the panel that holds the Noru launcher (or the first panel)
    dbus-send --session --type=method_call --dest=org.kde.plasmashell /PlasmaShell \
      org.kde.PlasmaShell.evaluateScript string:'
      var ps = panels(), target = null, found = false;
      for (var i = 0; i < ps.length; i++)
        for (var j = 0; j < ps[i].widgetIds.length; j++) {
          var t = ps[i].widgetById(ps[i].widgetIds[j]).type;
          if (t == "org.noru.launcher") target = ps[i];
          if (t == "'$ID'") found = true;
        }
      if (!target && ps.length > 0) target = ps[0];
      if (target && !found) target.addWidget("'$ID'");' >/dev/null
    echo "Added. Drag it where you want in panel edit mode."
    ;;
  uninstall)
    kpackagetool6 --type Plasma/Applet --remove $ID || true
    echo "Removed."
    ;;
  *) echo "usage: $0 [install|add-to-panel|uninstall]"; exit 1;;
esac
