# Noru Task Switcher button

A taskbar button that opens the KDE task switcher. Click = show open windows.

    ./install.sh               # install
    ./install.sh add-to-panel  # put it on your panel next to Noru
    ./install.sh uninstall

Right-click the button -> Configure to choose what it opens:
- Task Switcher: whichever Alt+Tab switcher you set in System Settings -> Window Management -> Task Switcher
- Overview
- Grid View

It works by asking KWin to run its own shortcut action over D-Bus (needs `dbus-send`, from the `dbus` package).
If the task switcher closes right away, pick Overview. You can also assign a keyboard shortcut to the widget in its settings.
