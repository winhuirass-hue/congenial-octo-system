/*
 * Dim Behind Dialogs (KWin 6 scripted effect)
 *
 * While a dialog is visible, every other normal window/dialog on the same screen is dimmed
 * (brightness + saturation), including fullscreen programs. Nothing is dimmed only when the
 * dialog itself is fullscreen.
 *
 * Settings live in kwinrc, group [Effect-noru-dimdialog] (see install.sh "set"):
 *   DimStrength      0-100  how dark (default 40)
 *   Desaturate       0-100  how much color is removed (default 25)
 *   DimPanels        bool   also dim panels/docks (default false)
 *   SkipFullscreen   bool   don't dim when the dialog itself is fullscreen (default true)
 *   SkipIfAppFullscreen bool  also don't dim when any fullscreen program is on the screen (default false)
 *   FadeMs           ms     fade time (default 180)
 */
"use strict";

class DimDialog {
    constructor() {
        this.dimmed = new Set();    // windows currently dimmed by us
        this.closing = new Set();   // windows on their way out
        this.loadConfig();
        effect.configChanged.connect(this.onConfig.bind(this));

        // Hook every signal that can change which windows are visible/active.
        // Unknown names on a given KWin version are skipped instead of breaking the effect.
        const refresh = this.update.bind(this);
        for (const name of ["windowAdded", "windowActivated", "windowMinimized", "windowUnminimized",
                            "windowShown", "windowHidden", "windowModalityChanged",
                            "windowFullScreenChanged", "desktopChanged", "currentDesktopChanged"]) {
            this.hook(name, refresh);
        }
        this.hook("windowClosed", this.onClosed.bind(this));
        this.hook("windowDeleted", this.onDeleted.bind(this));

        this.update();
    }

    hook(name, fn) {
        try {
            if (effects[name] && effects[name].connect) effects[name].connect(fn);
        } catch (e) {
            console.warn("noru-dimdialog: cannot connect " + name + ": " + e);
        }
    }

    // ---- config ----
    loadConfig() {
        const num = (k, d) => { const v = Number(effect.readConfig(k, d)); return isNaN(v) ? d : v; };
        const bool = (k, d) => { const v = effect.readConfig(k, d); return v === true || v === "true"; };
        const strength = Math.max(0, Math.min(100, num("DimStrength", 40)));
        const desat = Math.max(0, Math.min(100, num("Desaturate", 25)));
        this.brightness = 1 - strength / 100;
        this.saturation = 1 - desat / 100;
        this.dimPanels = bool("DimPanels", false);
        this.skipFullscreen = !(effect.readConfig("SkipFullscreen", true) === false ||
                                effect.readConfig("SkipFullscreen", true) === "false");
        this.skipIfAppFullscreen = bool("SkipIfAppFullscreen", false);
        this.fadeMs = animationTime(num("FadeMs", 180));
    }

    onConfig() {
        this.loadConfig();
        // re-apply with the new strength
        for (const w of Array.from(this.dimmed)) this.undim(w, true);
        this.update();
    }

    // ---- window classification ----
    live(w) {
        return w && w.visible && !w.minimized && !w.deleted && !this.closing.has(w) &&
               (w.onCurrentDesktop === undefined || w.onCurrentDesktop);
    }

    isDialog(w) {
        return w.dialog === true;
    }

    dimmable(w) {
        return w.normalWindow || w.dialog || (this.dimPanels && w.dock);
    }

    sameScreen(a, b) {
        try { return a.screen === undefined || b.screen === undefined || a.screen === b.screen; }
        catch (e) { return true; }
    }

    // ---- main logic ----
    update() {
        const wins = effects.stackingOrder.filter(this.live.bind(this));

        // topmost visible dialog is the one we keep bright
        let target = null;
        for (let i = wins.length - 1; i >= 0; i--) {
            if (this.isDialog(wins[i])) { target = wins[i]; break; }
        }

        let active = target !== null;
        // Dialog itself fullscreen -> no dimming. Fullscreen *programs* behind a normal dialog are dimmed.
        if (active && this.skipFullscreen && target.fullScreen) active = false;
        if (active && this.skipIfAppFullscreen &&
            wins.some(w => w !== target && w.fullScreen && this.sameScreen(w, target))) active = false;

        const want = new Set();
        if (active) {
            for (const w of wins) {
                if (w !== target && this.dimmable(w) && this.sameScreen(w, target)) want.add(w);
            }
        }

        for (const w of Array.from(this.dimmed)) if (!want.has(w)) this.undim(w, false);
        for (const w of want) if (!this.dimmed.has(w)) this.dim(w);
    }

    dim(w) {
        this.dimmed.add(w);
        if (w.noruDimAnim) cancel(w.noruDimAnim);
        w.noruDimAnim = set({
            window: w,
            duration: this.fadeMs,
            curve: QEasingCurve.OutCubic,
            animations: [
                { type: Effect.Brightness, to: this.brightness },
                { type: Effect.Saturation, to: this.saturation }
            ]
        });
    }

    undim(w, instant) {
        this.dimmed.delete(w);
        if (w.noruDimAnim) { cancel(w.noruDimAnim); w.noruDimAnim = null; }
        if (instant || w.deleted) return;
        try {
            animate({
                window: w,
                duration: this.fadeMs,
                curve: QEasingCurve.OutCubic,
                animations: [
                    { type: Effect.Brightness, from: this.brightness, to: 1.0 },
                    { type: Effect.Saturation, from: this.saturation, to: 1.0 }
                ]
            });
        } catch (e) { /* window vanished */ }
    }

    onClosed(w) {
        this.closing.add(w);
        this.dimmed.delete(w);
        this.update();
    }

    onDeleted(w) {
        this.closing.delete(w);
        this.dimmed.delete(w);
    }
}

new DimDialog();
