# Dim Behind Dialogs (KWin 6 effect)

While a dialog is open, all other windows on that screen are dimmed, **including fullscreen programs**.
The only time it does not dim is when the dialog itself is fullscreen.

    ./install.sh                                  # install + enable
    ./install.sh set 50 30                        # 50% darker, 30% less color
    ./install.sh set 40 25 true                   # also dim panels
    ./install.sh set 40 25 false false            # dim even if the dialog is fullscreen
    ./install.sh set 40 25 false true true        # old behavior: also skip when any fullscreen program is present
    ./install.sh disable | uninstall

Settings: DimStrength, Desaturate, DimPanels, SkipFullscreen (dialog itself fullscreen, default true),
SkipIfAppFullscreen (default false), FadeMs, in kwinrc group [Effect-noru-dimdialog].
Also visible in System Settings -> Window Management -> Desktop Effects (category Focus).
Debug: `journalctl --user -b | grep -i dimdialog`.
Needs Plasma 6, kpackagetool6, kwriteconfig6, dbus-send.
