#!/usr/bin/env bash
# Dim Behind Dialogs: KWin 6 effect installer (user-level)
set -euo pipefail
cd "$(dirname "$0")"
ID=noru-dimdialog
GROUP="Effect-$ID"

kwin_reconfigure() { dbus-send --session --type=method_call --dest=org.kde.KWin /KWin org.kde.KWin.reconfigure 2>/dev/null || true; }
effects_call()    { dbus-send --session --type=method_call --dest=org.kde.KWin /Effects "org.kde.kwin.Effects.$1" string:"$ID" 2>/dev/null || true; }

case "${1:-install}" in
  install)
    command -v kpackagetool6 >/dev/null || { echo "kpackagetool6 not found (Plasma 6 required)"; exit 1; }
    kpackagetool6 --type KWin/Effect --upgrade ./effect >/dev/null 2>&1 || kpackagetool6 --type KWin/Effect --install ./effect
    kwriteconfig6 --file kwinrc --group Plugins --key "${ID}Enabled" true
    kwin_reconfigure
    effects_call unloadEffect
    effects_call loadEffect
    echo "Installed and enabled. Open any dialog (e.g. File -> Open) to see it."
    echo "Tune it with: $0 set <strength 0-100> [desaturate 0-100] [panels true|false] [skip-if-dialog-fullscreen true|false] [skip-if-app-fullscreen true|false]"
    ;;
  set)
    [ $# -ge 2 ] || { echo "usage: $0 set <strength> [desaturate] [panels] [skip-if-dialog-fullscreen] [skip-if-app-fullscreen]"; exit 1; }
    kwriteconfig6 --file kwinrc --group "$GROUP" --key DimStrength "$2"
    [ -n "${3:-}" ] && kwriteconfig6 --file kwinrc --group "$GROUP" --key Desaturate "$3"
    [ -n "${4:-}" ] && kwriteconfig6 --file kwinrc --group "$GROUP" --key DimPanels "$4"
    [ -n "${5:-}" ] && kwriteconfig6 --file kwinrc --group "$GROUP" --key SkipFullscreen "$5"
    [ -n "${6:-}" ] && kwriteconfig6 --file kwinrc --group "$GROUP" --key SkipIfAppFullscreen "$6"
    kwin_reconfigure
    echo "Settings saved."
    ;;
  disable)
    kwriteconfig6 --file kwinrc --group Plugins --key "${ID}Enabled" false
    effects_call unloadEffect; kwin_reconfigure; echo "Disabled."
    ;;
  uninstall)
    kwriteconfig6 --file kwinrc --group Plugins --key "${ID}Enabled" false
    effects_call unloadEffect
    kpackagetool6 --type KWin/Effect --remove "$ID" || true
    kwin_reconfigure; echo "Removed."
    ;;
  *) echo "usage: $0 [install|set|disable|uninstall]"; exit 1;;
esac
