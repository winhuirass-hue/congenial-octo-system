/* Noru Motion (KWin 6 scripted effect) */
"use strict";

class NoruMotion {
    constructor() {
        this.openMs = animationTime(260);
        this.closeMs = animationTime(180);
        this.slide = 70;   // px the window rises from on open
        effects.windowAdded.connect(this.onAdded.bind(this));
        effects.windowClosed.connect(this.onClosed.bind(this));
        effect.animationEnded.connect(this.onEnded.bind(this));
    }

    eligible(w) {
        return w.normalWindow || w.dialog;
    }

    onAdded(w) {
        if (!this.eligible(w)) return;
        if (w.noruOpen) cancel(w.noruOpen);
        w.noruOpen = animate({
            window: w,
            curve: QEasingCurve.OutCubic,
            duration: this.openMs,
            animations: [
                { type: Effect.Translation, from: { value1: 0, value2: this.slide }, to: { value1: 0, value2: 0 } },
                { type: Effect.Scale, from: 0.94, to: 1.0 },
                { type: Effect.Opacity, from: 0.0, to: 1.0 }
            ]
        });
    }

    onClosed(w) {
        if (!w.visible || !this.eligible(w)) return;
        if (w.noruOpen) { cancel(w.noruOpen); w.noruOpen = null; }
        w.setData(Effect.WindowClosedGrabRole, this);
        w.noruClose = animate({
            window: w,
            curve: QEasingCurve.InCubic,
            duration: this.closeMs,
            animations: [
                { type: Effect.Scale, from: 1.0, to: 0.92 },
                { type: Effect.Opacity, from: 1.0, to: 0.0 }
            ]
        });
    }

    onEnded(w) {
        w.setData(Effect.WindowClosedGrabRole, null);
        w.noruOpen = null;
        w.noruClose = null;
    }
}

new NoruMotion();
