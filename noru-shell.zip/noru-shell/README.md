# Noru Shell: a mobile-style shell on desktop KDE Plasma 6

| Layer | What it does | Where |
|---|---|---|
| Window rules | Every normal window is forced maximized and borderless | written by `install.sh` into `kwinrulesrc` |
| KWin script `noru-mobile` | Home / Back / Next / Recents / Close actions, recent-app history, dialogs centered, touch-edge gestures, mobile/desktop toggle | `kwin-script/` |
| KWin effect `noru-motion` | Apps slide up and fade in; shrink and fade out on close | `kwin-effect/` |
| Task switcher `noru-recents` | Phone-style recents carousel: tap opens, swipe a card up closes, "Clear all" | `task-switcher/` |
| Plasmoid `org.noru.navbar` | Bottom bar: 3 buttons **or** gesture pill (tap = Home, swipe up = Recents, swipe left/right = Back/Next) | `plasmoids/navbar/` |
| Plasmoid `org.noru.home` | Home screen: big clock, search on top, auto-fitting scrolling app grid | `plasmoids/home/` |
| Layout script | Top status bar (clock + system tray), bottom nav bar, home widget on the desktop | `layout/layout.js` |

## Requirements
Plasma 6 (Wayland session recommended, needed for touch edges), plus `kpackagetool6`, `kwriteconfig6`,
`kreadconfig6` and `dbus-send` (package `dbus`). On Ubuntu: `sudo apt install kpackagetool6 kde-cli-tools dbus`.
For typing without a keyboard enable System Settings -> Keyboard -> Virtual Keyboard.

## Use
    ./install.sh                 # install + enable (rules, script, effect, task switcher, plasmoids)
    ./install.sh layout          # add top status bar, bottom nav bar and home widget
    ./install.sh layout --replace  # same, removing existing panels first
    ./install.sh desktop         # back to normal windows (disables script/effect/rules/switcher)
    ./install.sh mobile          # re-enable mobile behavior
    ./install.sh uninstall

Log out and in once after the first install so KWin picks everything up.

Shortcuts (rebind in System Settings -> Keyboard -> Shortcuts, search "Noru"):
Meta+Home = Home, Meta+Backspace = Back (previous app), Meta+Tab = Recents, Meta+Alt+M = toggle mode.

## Known limitations (untested build)
- "Back" means "previous app", not an in-app back action (Wayland does not let a shell inject keys into apps).
- Recents from the nav bar/edge works by asking KWin to run "Walk Through Windows"; the switcher must be set to
  Noru Recents (done by the installer under System Settings -> Window Management -> Task Switcher).
- Touch-edge gestures use KWin's script API and may need enabling touch edges for your device.
- Home screen/search use Plasma's private Kicker models and the switcher uses KWin's QML switcher API; both can
  change between Plasma releases.
- Debug: `journalctl --user -b | grep -iE "kwin|noru"`; test a widget with `plasmawindowed org.noru.home`.
