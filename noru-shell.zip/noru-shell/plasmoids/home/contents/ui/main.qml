import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents3
import org.kde.plasma.extras as PlasmaExtras
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.kicker as Kicker

PlasmoidItem {
    id: root
    preferredRepresentation: fullRepresentation
    Plasmoid.backgroundHints: "NoBackground"

    property string query: ""
    property var appsModel: null
    property var searchModel: null
    readonly property var activeModel: query.length > 0 ? searchModel : appsModel

    Kicker.RootModel {
        id: rootModel
        autoPopulate: false
        appletInterface: root
        flat: false
        sorted: true
        showSeparators: false
        showAllApps: true
        showAllAppsCategorized: false
        showTopLevelItems: false
        showRecentApps: false
        showRecentDocs: false
        showPowerSession: false
        showFavoritesPlaceholder: false
        Component.onCompleted: refresh()
    }
    Kicker.RunnerModel {
        id: runnerModel
        appletInterface: root
        mergeResults: true
        query: root.query
    }
    Connections {
        target: rootModel
        function onCountChanged() { root.appsModel = rootModel.count > 0 ? rootModel.modelForRow(0) : null }
    }
    Connections {
        target: runnerModel
        function onCountChanged() { root.searchModel = runnerModel.count > 0 ? runnerModel.modelForRow(0) : null }
    }
    onQueryChanged: searchModel = runnerModel.count > 0 ? runnerModel.modelForRow(0) : null

    function launch(m, i) { if (m && i >= 0) m.trigger(i, "", null) }

    fullRepresentation: Item {
        id: screen
        Layout.minimumWidth: Kirigami.Units.gridUnit * 20
        Layout.minimumHeight: Kirigami.Units.gridUnit * 30

        property date now: new Date()
        Timer { interval: 1000; running: true; repeat: true; onTriggered: screen.now = new Date() }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.gridUnit * 1.5
            spacing: Kirigami.Units.largeSpacing

            // clock header
            ColumnLayout {
                Layout.fillWidth: true
                visible: root.query.length === 0
                spacing: 0
                Text {
                    Layout.alignment: Qt.AlignHCenter
                    text: Qt.formatTime(screen.now, "hh:mm")
                    font.pixelSize: Kirigami.Units.gridUnit * 4.5
                    font.weight: Font.Light
                    color: "white"
                    style: Text.Outline
                    styleColor: "#66000000"
                }
                Text {
                    Layout.alignment: Qt.AlignHCenter
                    text: Qt.formatDate(screen.now, "dddd, d MMMM")
                    font.pixelSize: Kirigami.Units.gridUnit * 1.2
                    color: "white"
                    style: Text.Outline
                    styleColor: "#66000000"
                }
            }

            // search on top of the grid
            PlasmaExtras.SearchField {
                id: searchField
                Layout.fillWidth: true
                Layout.maximumWidth: Kirigami.Units.gridUnit * 28
                Layout.alignment: Qt.AlignHCenter
                placeholderText: i18n("Search apps, files, settings…")
                onTextChanged: root.query = text
                onAccepted: if (grid.count > 0) root.launch(root.activeModel, 0)
                Keys.onDownPressed: grid.forceActiveFocus()
            }

            // app grid (scrolls vertically, columns auto-fit)
            GridView {
                id: grid
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: root.activeModel
                keyNavigationEnabled: true

                readonly property int iconSize: Kirigami.Units.iconSizes.huge
                readonly property int cols: Math.max(3, Math.floor(width / (iconSize + Kirigami.Units.gridUnit * 3.5)))
                cellWidth: Math.floor(width / cols)
                cellHeight: iconSize + Kirigami.Units.gridUnit * 3

                Keys.onReturnPressed: root.launch(root.activeModel, currentIndex)
                PlasmaComponents3.ScrollBar.vertical: PlasmaComponents3.ScrollBar {}

                delegate: MouseArea {
                    id: tile
                    width: grid.cellWidth
                    height: grid.cellHeight
                    hoverEnabled: true
                    onClicked: root.launch(root.activeModel, index)

                    Rectangle {
                        anchors.fill: parent
                        anchors.margins: 4
                        radius: 16
                        color: tile.pressed ? "#55ffffff" : (tile.containsMouse ? "#22ffffff" : "transparent")
                    }
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 6
                        spacing: 4
                        Item { Layout.fillHeight: true }
                        Kirigami.Icon {
                            Layout.alignment: Qt.AlignHCenter
                            Layout.preferredWidth: grid.iconSize
                            Layout.preferredHeight: grid.iconSize
                            source: model.decoration
                        }
                        Text {
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            text: model.display
                            color: "white"
                            elide: Text.ElideRight
                            maximumLineCount: 2
                            wrapMode: Text.Wrap
                            style: Text.Outline
                            styleColor: "#66000000"
                        }
                        Item { Layout.fillHeight: true }
                    }
                }
            }
        }
    }
}
