import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.plasma5support as P5Support
import org.kde.plasma.components as PlasmaComponents3
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root
    preferredRepresentation: fullRepresentation
    Plasmoid.backgroundHints: "NoBackground"

    // Runs a command line (used to trigger the Noru KWin script's shortcuts over D-Bus)
    P5Support.DataSource {
        id: exec
        engine: "executable"
        connectedSources: []
        onNewData: (source, data) => disconnectSource(source)
        function run(cmd) { connectSource(cmd) }
    }

    function action(name) {
        exec.run("dbus-send --session --type=method_call --dest=org.kde.kglobalaccel " +
                 "/component/kwin org.kde.kglobalaccel.Component.invokeShortcut string:'" + name + "'")
    }
    function home()    { action("Noru: Home") }
    function back()    { action("Noru: Back") }
    function next()    { action("Noru: Next app") }
    function recents() { action("Noru: Recents") }

    fullRepresentation: Item {
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.minimumWidth: Kirigami.Units.gridUnit * 12
        Layout.minimumHeight: Kirigami.Units.gridUnit * 2

        // ---- 3-button mode ----
        RowLayout {
            anchors.fill: parent
            visible: Plasmoid.configuration.navMode === 0
            spacing: 0
            Repeater {
                model: [
                    { icon: "go-previous", tip: i18n("Back"),    fn: "back" },
                    { icon: "go-home",     tip: i18n("Home"),    fn: "home" },
                    { icon: "window-duplicate", tip: i18n("Recents"), fn: "recents" }
                ]
                delegate: PlasmaComponents3.ToolButton {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    icon.name: modelData.icon
                    icon.width: Kirigami.Units.iconSizes.smallMedium
                    icon.height: Kirigami.Units.iconSizes.smallMedium
                    display: PlasmaComponents3.AbstractButton.IconOnly
                    onClicked: root[modelData.fn]()
                }
            }
        }

        // ---- gesture pill mode ----
        Item {
            anchors.fill: parent
            visible: Plasmoid.configuration.navMode === 1

            Rectangle {
                id: pill
                anchors.centerIn: parent
                width: Math.min(parent.width * 0.35, Kirigami.Units.gridUnit * 9)
                height: Math.max(6, Math.round(Kirigami.Units.gridUnit * 0.35))
                radius: height / 2
                color: Kirigami.Theme.textColor
                opacity: gesture.pressed ? 1.0 : 0.65
                Behavior on opacity { NumberAnimation { duration: 120 } }
            }

            MouseArea {
                id: gesture
                anchors.fill: parent
                property real sx: 0
                property real sy: 0
                onPressed: (m) => { sx = m.x; sy = m.y }
                onReleased: (m) => {
                    const dx = m.x - sx, dy = m.y - sy
                    const th = Kirigami.Units.gridUnit * 1.5
                    if (Math.abs(dy) > th && Math.abs(dy) > Math.abs(dx)) {
                        if (dy < 0) root.recents()
                        else root.home()
                    } else if (Math.abs(dx) > th) {
                        if (dx < 0) root.back(); else root.next()
                    } else {
                        root.home()
                    }
                }
            }
        }
    }
}
