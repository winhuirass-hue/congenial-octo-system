import QtQuick
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami
import org.kcmutils as KCM

KCM.SimpleKCM {
    property alias cfg_navMode: modeBox.currentIndex

    Kirigami.FormLayout {
        QQC2.ComboBox {
            id: modeBox
            Kirigami.FormData.label: i18n("Navigation style:")
            model: [i18n("3 buttons (Back, Home, Recents)"), i18n("Gesture pill (tap = Home, swipe up = Recents, swipe left/right = Back/Next)")]
        }
    }
}
