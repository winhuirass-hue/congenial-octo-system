/*
 * Noru Mobile Shell (KWin 6 script)
 *
 * Actions (global shortcuts, also invoked by the Noru navigation bar over D-Bus):
 *   Noru: Home        Meta+Home       show the home screen
 *   Noru: Back        Meta+Backspace  previous app
 *   Noru: Next app                    oldest app in the recent list
 *   Noru: Recents     Meta+Tab        open the task switcher (select "Noru Recents" in Task Switcher settings)
 *   Noru: Close app                   close active window
 *   Noru: Toggle mobile/desktop mode  Meta+Alt+M
 *
 * Touch edges (if supported by your session): bottom = Home, left = Back, right = Recents.
 */
"use strict";

let mobile = true;
let history = [];   // most-recently-used normal windows, [0] = newest

// ---- helpers ----
function eligible(w) {
    return w && w.normalWindow;
}

function center(w) {
    if (!w.moveable) return;
    const area = workspace.clientArea(KWin.PlacementArea, w);
    const g = w.frameGeometry;
    w.frameGeometry = {
        x: Math.round(area.x + (area.width - g.width) / 2),
        y: Math.round(area.y + (area.height - g.height) / 2),
        width: g.width,
        height: g.height
    };
}

function apply(w) {
    if (!w) return;
    if (eligible(w)) {
        if (mobile) {
            if (w.maximizable) w.setMaximize(true, true);
            w.noBorder = true;
        } else {
            w.noBorder = false;
        }
    } else if (w.dialog && mobile) {
        center(w);
    }
}

function activate(w) {
    if (!w) return;
    if (w.minimized) w.minimized = false;
    workspace.activeWindow = w;
}

// ---- recent list ----
function remember(w) {
    if (!eligible(w)) return;
    history = history.filter(function (x) { return x !== w; });
    history.unshift(w);
}

workspace.windowAdded.connect(apply);
workspace.windowActivated.connect(remember);
workspace.windowRemoved.connect(function (w) {
    history = history.filter(function (x) { return x !== w; });
});

workspace.windowList().forEach(apply);
remember(workspace.activeWindow);

// ---- actions ----
function goHome() {
    workspace.showingDesktop = true;
}

function goBack() {
    const idx = (workspace.showingDesktop || workspace.activeWindow !== history[0]) ? 0 : 1;
    activate(history[idx]);
}

function goNext() {
    if (history.length > 1) activate(history[history.length - 1]);
}

function openRecents() {
    // Ask KWin to run its own "Walk Through Windows" action, which opens the active Task Switcher.
    callDBus("org.kde.kglobalaccel", "/component/kwin",
             "org.kde.kglobalaccel.Component", "invokeShortcut", "Walk Through Windows");
}

function closeApp() {
    const w = workspace.activeWindow;
    if (eligible(w)) w.closeWindow();
}

function toggleMode() {
    mobile = !mobile;
    workspace.windowList().forEach(apply);
}

registerShortcut("Noru: Home", "Noru: Home", "Meta+Home", goHome);
registerShortcut("Noru: Back", "Noru: Back (previous app)", "Meta+Backspace", goBack);
registerShortcut("Noru: Next app", "Noru: Next app", "", goNext);
registerShortcut("Noru: Recents", "Noru: Recents", "Meta+Tab", openRecents);
registerShortcut("Noru: Close app", "Noru: Close app", "", closeApp);
registerShortcut("Noru: Toggle mobile mode", "Noru: Toggle mobile/desktop mode", "Meta+Alt+M", toggleMode);

// ---- touch screen edges (best effort) ----
// ElectricBorder order: Top=0, TopRight=1, Right=2, BottomRight=3, Bottom=4, BottomLeft=5, Left=6, TopLeft=7
try {
    registerTouchScreenEdge(4, goHome);
    registerTouchScreenEdge(6, goBack);
    registerTouchScreenEdge(2, openRecents);
} catch (e) {
    console.warn("Noru: touch edges unavailable: " + e);
}
