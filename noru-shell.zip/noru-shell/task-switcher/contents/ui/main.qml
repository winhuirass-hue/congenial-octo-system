/* Noru Recents: KWin 6 task switcher */
import QtQuick
import QtQuick.Layouts
import QtQuick.Window
import org.kde.kirigami as Kirigami
import org.kde.kwin as KWin

KWin.TabBoxSwitcher {
    id: tabBox
    currentIndex: view.currentIndex

    Connections {
        target: tabBox
        function onCurrentIndexChanged() { view.currentIndex = tabBox.currentIndex }
    }

    Window {
        id: overlay
        visible: tabBox.visible
        flags: Qt.BypassWindowManagerHint | Qt.FramelessWindowHint
        color: "transparent"
        x: tabBox.screenGeometry.x
        y: tabBox.screenGeometry.y
        width: tabBox.screenGeometry.width
        height: tabBox.screenGeometry.height

        readonly property real cardW: Math.min(width * 0.42, 560)
        readonly property real cardH: cardW * 1.35 > height * 0.68 ? height * 0.68 : cardW * 1.35

        Rectangle {
            anchors.fill: parent
            color: "#cc0b0e14"

            // tap outside cards = open the highlighted app
            MouseArea {
                anchors.fill: parent
                onClicked: tabBox.model.activate(view.currentIndex)
            }

            ListView {
                id: view
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.verticalCenterOffset: -overlay.height * 0.03
                height: overlay.cardH + 90
                orientation: ListView.Horizontal
                spacing: 28
                model: tabBox.model
                clip: false
                highlightRangeMode: ListView.StrictlyEnforceRange
                preferredHighlightBegin: width / 2 - overlay.cardW / 2
                preferredHighlightEnd: width / 2 + overlay.cardW / 2
                highlightMoveDuration: 220
                keyNavigationEnabled: false

                delegate: Item {
                    id: slot
                    width: overlay.cardW
                    height: view.height
                    readonly property bool current: ListView.isCurrentItem

                    Item {
                        id: card
                        width: parent.width
                        height: overlay.cardH
                        y: 70
                        scale: slot.current ? 1.0 : 0.86
                        opacity: slot.current ? 1.0 : 0.65
                        Behavior on scale { NumberAnimation { duration: 180 } }
                        Behavior on opacity { NumberAnimation { duration: 180 } }
                        Behavior on y { enabled: !drag.active; NumberAnimation { duration: 160 } }

                        // header: icon + title
                        RowLayout {
                            id: header
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.bottom: body.top
                            anchors.bottomMargin: 8
                            spacing: 10
                            Kirigami.Icon {
                                source: model.icon
                                Layout.preferredWidth: 32
                                Layout.preferredHeight: 32
                            }
                            Text {
                                Layout.fillWidth: true
                                text: model.caption
                                color: "white"
                                elide: Text.ElideRight
                                font.pixelSize: 16
                            }
                        }

                        Rectangle {
                            id: body
                            anchors.fill: parent
                            radius: 22
                            color: "#1a1f29"
                            border.color: slot.current ? "#6d5dfc" : "#2a303c"
                            border.width: slot.current ? 3 : 1
                            clip: true

                            KWin.WindowThumbnail {
                                anchors.fill: parent
                                anchors.margins: 4
                                client: model.client
                            }
                        }

                        TapHandler {
                            onTapped: {
                                view.currentIndex = index
                                tabBox.model.activate(index)
                            }
                        }

                        // swipe up to close
                        DragHandler {
                            id: drag
                            xAxis.enabled: false
                            yAxis.maximum: 70
                            onActiveChanged: {
                                if (!active) {
                                    if (card.y < 70 - overlay.cardH * 0.25) {
                                        tabBox.model.close(index)
                                    }
                                    card.y = 70
                                }
                            }
                            target: card
                        }
                    }
                }
            }

            // Clear all
            Rectangle {
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: overlay.height * 0.07
                width: clearLabel.implicitWidth + 48
                height: 44
                radius: 22
                color: "#2a303c"
                visible: view.count > 0
                Text {
                    id: clearLabel
                    anchors.centerIn: parent
                    text: "Clear all"
                    color: "white"
                    font.pixelSize: 15
                }
                TapHandler {
                    onTapped: {
                        for (let i = view.count - 1; i >= 0; i--) tabBox.model.close(i)
                    }
                }
            }
        }
    }
}
