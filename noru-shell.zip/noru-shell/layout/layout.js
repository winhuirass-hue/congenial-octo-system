// Plasma shell layout script. REPLACE is prepended by install.sh.
if (typeof REPLACE !== "undefined" && REPLACE) {
    var old = panels();
    for (var i = 0; i < old.length; i++) old[i].remove();
}

// Status bar (top)
var top = new Panel();
top.location = "top";
top.height = 30;
top.addWidget("org.kde.plasma.digitalclock");
top.addWidget("org.kde.plasma.panelspacer");
top.addWidget("org.kde.plasma.systemtray");

// Navigation bar (bottom)
var nav = new Panel();
nav.location = "bottom";
nav.height = 56;
nav.addWidget("org.noru.navbar");

// Home screen on the first desktop
var d = desktops()[0];
var g = screenGeometry(d.screen);
d.addWidget("org.noru.home", 0, 0, g.width, g.height - 86);
