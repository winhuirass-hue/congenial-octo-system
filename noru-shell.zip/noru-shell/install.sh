#!/usr/bin/env bash
# Noru Shell: mobile-style shell on top of desktop KDE Plasma 6 (user-level install)
set -euo pipefail
cd "$(dirname "$0")"

for t in kpackagetool6 kwriteconfig6 kreadconfig6 dbus-send; do
  command -v "$t" >/dev/null || { echo "Missing tool: $t (see README)"; exit 1; }
done

RULE_ID="noru-mobile-apps"

kwin_reconfigure() {
  dbus-send --session --type=method_call --dest=org.kde.KWin /KWin org.kde.KWin.reconfigure 2>/dev/null || true
}

pkg() { # type path
  kpackagetool6 --type "$1" --upgrade "$2" >/dev/null 2>&1 || kpackagetool6 --type "$1" --install "$2"
}

rules_list() { kreadconfig6 --file kwinrulesrc --group General --key rules --default ""; }
rules_set() {
  local list="$1" count=0
  [ -n "$list" ] && count=$(awk -F, '{print NF}' <<<"$list")
  kwriteconfig6 --file kwinrulesrc --group General --key rules "$list"
  kwriteconfig6 --file kwinrulesrc --group General --key count "$count"
}
rules_add() {
  local cur; cur=$(rules_list)
  case ",$cur," in *",$1,"*) return;; esac
  rules_set "${cur:+$cur,}$1"
}
rules_remove() {
  local cur new; cur=$(rules_list)
  new=$(sed -e "s/^/,/" -e "s/\$/,/" -e "s/,$1,/,/" -e "s/^,//" -e "s/,\$//" <<<"$cur")
  rules_set "$new"
}

write_rule() {
  local g="$RULE_ID" k
  kwriteconfig6 --file kwinrulesrc --group "$g" --key Description "Noru: phone-style apps (maximized, no titlebar)"
  kwriteconfig6 --file kwinrulesrc --group "$g" --key wmclass ".*"
  kwriteconfig6 --file kwinrulesrc --group "$g" --key wmclassmatch 3
  kwriteconfig6 --file kwinrulesrc --group "$g" --key wmclasscomplete false
  kwriteconfig6 --file kwinrulesrc --group "$g" --key types 1
  for k in maximizehoriz maximizevert noborder; do
    kwriteconfig6 --file kwinrulesrc --group "$g" --key "$k" true
    kwriteconfig6 --file kwinrulesrc --group "$g" --key "${k}rule" 2     # 2 = Force
  done
  rules_add "$RULE_ID"
}

mobile_on() {
  kwriteconfig6 --file kwinrc --group Plugins --key noru-mobileEnabled true
  kwriteconfig6 --file kwinrc --group Plugins --key noru-motionEnabled true
  kwriteconfig6 --file kwinrc --group TabBox --key LayoutName noru-recents
  write_rule
  kwin_reconfigure
}

mobile_off() {
  kwriteconfig6 --file kwinrc --group Plugins --key noru-mobileEnabled false
  kwriteconfig6 --file kwinrc --group Plugins --key noru-motionEnabled false
  kwriteconfig6 --file kwinrc --group TabBox --key LayoutName thumbnails
  rules_remove "$RULE_ID"
  kwin_reconfigure
}

apply_layout() { # [replace]
  local pre="var REPLACE=${1:-false};"
  dbus-send --session --type=method_call --print-reply --dest=org.kde.plasmashell \
    /PlasmaShell org.kde.PlasmaShell.evaluateScript string:"$pre
$(cat layout/layout.js)" >/dev/null
}

case "${1:-install}" in
  install)
    pkg KWin/Script          ./kwin-script
    pkg KWin/Effect          ./kwin-effect
    pkg KWin/WindowSwitcher  ./task-switcher
    pkg Plasma/Applet        ./plasmoids/navbar
    pkg Plasma/Applet        ./plasmoids/home
    mobile_on
    cat <<MSG

Noru Shell installed and enabled.
  ./install.sh layout            add status bar (top), nav bar (bottom) and home screen widget
  ./install.sh layout --replace  same, but removes your existing panels first
  ./install.sh desktop           switch back to normal desktop behavior
  ./install.sh mobile            switch to mobile behavior again
  ./install.sh uninstall         remove everything
Shortcuts: Meta+Home = Home, Meta+Backspace = Back, Meta+Tab = Recents, Meta+Alt+M = toggle mobile/desktop.
MSG
    ;;
  layout)
    if [ "${2:-}" = "--replace" ]; then apply_layout true; else apply_layout false; fi
    echo "Layout applied."
    ;;
  mobile)  mobile_on;  echo "Mobile mode on." ;;
  desktop) mobile_off; echo "Desktop mode on (packages stay installed)." ;;
  uninstall)
    mobile_off
    kpackagetool6 --type KWin/Script         --remove noru-mobile  || true
    kpackagetool6 --type KWin/Effect         --remove noru-motion  || true
    kpackagetool6 --type KWin/WindowSwitcher --remove noru-recents || true
    kpackagetool6 --type Plasma/Applet       --remove org.noru.navbar || true
    kpackagetool6 --type Plasma/Applet       --remove org.noru.home   || true
    kwriteconfig6 --file kwinrulesrc --group "$RULE_ID" --key Description --delete 2>/dev/null || true
    echo "Removed. Remove the Noru panels/widgets manually in edit mode if you applied the layout."
    ;;
  *) echo "usage: $0 [install|layout [--replace]|mobile|desktop|uninstall]"; exit 1;;
esac
