# Noru: mega menu launcher for KDE Plasma 6

A taskbar button that opens a mega menu:
- **Search on top**: apps, settings, files, calculator etc. (KRunner backends). Enter launches the first result, Down jumps to the grid.
- **App grid**: mobile-style tiles that re-flow automatically to the menu width.
- **Category sidebar** (toggle in settings): All Applications, Games, Office, etc.
- **Footer**: Lock / Log out / Restart / Shut down.

## Install
    ./install.sh              # install the widget
    ./install.sh add-to-panel # optional: adds the button to your first panel
    ./install.sh uninstall

Or right-click the panel -> Add Widgets -> Noru. Assign a shortcut (e.g. Meta) via widget settings -> Keyboard Shortcuts.
To replace the stock launcher, remove it in panel edit mode and drag Noru to its place.

Settings (right-click Noru -> Configure): icon size, sidebar on/off.

## Notes
Uses Plasma's `org.kde.plasma.private.kicker` models (same as the stock launcher), which are private
and may change between Plasma versions. Targets Plasma 6.x.
Debug QML errors with: `plasmawindowed org.noru.launcher`
