import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2
import org.kde.plasma.components as PlasmaComponents3
import org.kde.plasma.private.sessions as Sessions

RowLayout {
    spacing: 4

    Sessions.SessionManagement { id: sm }

    PlasmaComponents3.ToolButton {
        icon.name: "system-lock-screen"
        text: i18n("Lock")
        display: QQC2.AbstractButton.IconOnly
        QQC2.ToolTip.text: text
        QQC2.ToolTip.visible: hovered
        onClicked: sm.lock()
    }
    PlasmaComponents3.ToolButton {
        icon.name: "system-log-out"
        text: i18n("Log out")
        display: QQC2.AbstractButton.IconOnly
        QQC2.ToolTip.text: text
        QQC2.ToolTip.visible: hovered
        onClicked: sm.requestLogout()
    }
    PlasmaComponents3.ToolButton {
        icon.name: "system-reboot"
        text: i18n("Restart")
        display: QQC2.AbstractButton.IconOnly
        QQC2.ToolTip.text: text
        QQC2.ToolTip.visible: hovered
        onClicked: sm.requestReboot()
    }
    PlasmaComponents3.ToolButton {
        icon.name: "system-shutdown"
        text: i18n("Shut down")
        display: QQC2.AbstractButton.IconOnly
        QQC2.ToolTip.text: text
        QQC2.ToolTip.visible: hovered
        onClicked: sm.requestShutdown()
    }
}
