/*
 * Noru: taskbar button + mega menu (search on top, auto-fitting app grid, category sidebar)
 * Uses Plasma's Kicker models (same backend as the stock Application Launcher / Dashboard).
 */
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents3
import org.kde.plasma.extras as PlasmaExtras
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.kicker as Kicker

PlasmoidItem {
    id: root

    property string query: ""
    property int selected: 0
    property var categoryModel: null
    property var searchModel: null
    readonly property var activeModel: query.length > 0 ? searchModel : categoryModel

    preferredRepresentation: compactRepresentation
    hideOnWindowDeactivate: true
    Plasmoid.icon: "view-app-grid"
    toolTipMainText: "Noru"
    toolTipSubText: i18n("Open the app menu")

    // ---- data ----
    Kicker.RootModel {
        id: rootModel
        autoPopulate: false
        appletInterface: root
        flat: false
        sorted: true
        showSeparators: false
        showAllApps: true
        showAllAppsCategorized: false
        showTopLevelItems: false
        showRecentApps: false
        showRecentDocs: false
        showPowerSession: false
        showFavoritesPlaceholder: false
        Component.onCompleted: refresh()
    }

    Kicker.RunnerModel {
        id: runnerModel
        appletInterface: root
        mergeResults: true
        query: root.query
    }

    Connections {
        target: rootModel
        function onCountChanged() { root.syncCategory() }
    }
    Connections {
        target: runnerModel
        function onCountChanged() { root.syncSearch() }
    }

    function syncCategory() {
        if (rootModel.count === 0) { categoryModel = null; return }
        if (selected < 0 || selected >= rootModel.count) selected = 0
        categoryModel = rootModel.modelForRow(selected)
    }

    function syncSearch() {
        searchModel = runnerModel.count > 0 ? runnerModel.modelForRow(0) : null
    }

    function selectCategory(i) {
        selected = i
        syncCategory()
    }

    function launch(m, i) {
        if (m && i >= 0 && m.trigger(i, "", null)) {
            expanded = false
        }
    }

    onQueryChanged: syncSearch()
    onExpandedChanged: if (expanded) { selected = 0; syncCategory() }

    // ---- taskbar button ----
    compactRepresentation: MouseArea {
        id: btn
        hoverEnabled: true
        activeFocusOnTab: true
        Layout.minimumWidth: Kirigami.Units.iconSizes.medium
        Layout.minimumHeight: Kirigami.Units.iconSizes.medium
        onClicked: root.expanded = !root.expanded

        Kirigami.Icon {
            anchors.fill: parent
            anchors.margins: Math.round(Math.min(parent.width, parent.height) * 0.1)
            source: Qt.resolvedUrl("../icons/noru.svg")
            active: btn.containsMouse
        }
    }

    // ---- mega menu ----
    fullRepresentation: Item {
        id: menu
        Layout.minimumWidth: Kirigami.Units.gridUnit * 44
        Layout.minimumHeight: Kirigami.Units.gridUnit * 30
        Layout.preferredWidth: Kirigami.Units.gridUnit * 52
        Layout.preferredHeight: Kirigami.Units.gridUnit * 34

        Keys.onEscapePressed: root.expanded = false

        Connections {
            target: root
            function onExpandedChanged() {
                if (root.expanded) {
                    searchField.text = ""
                    searchField.forceActiveFocus()
                }
            }
        }
        Component.onCompleted: searchField.forceActiveFocus()

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.largeSpacing
            spacing: Kirigami.Units.largeSpacing

            // Search on top
            PlasmaExtras.SearchField {
                id: searchField
                Layout.fillWidth: true
                placeholderText: i18n("Search apps, files, settings…")
                onTextChanged: root.query = text
                onAccepted: if (root.activeModel && grid.count > 0) root.launch(root.activeModel, 0)
                Keys.onDownPressed: grid.forceActiveFocus()
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: Kirigami.Units.largeSpacing

                // Category sidebar
                ListView {
                    id: cats
                    visible: Plasmoid.configuration.showSidebar && root.query.length === 0
                    Layout.preferredWidth: Kirigami.Units.gridUnit * 11
                    Layout.fillHeight: true
                    clip: true
                    model: rootModel
                    spacing: 2

                    delegate: MouseArea {
                        id: catItem
                        width: ListView.view.width
                        height: Kirigami.Units.gridUnit * 2.2
                        hoverEnabled: true
                        onClicked: root.selectCategory(index)

                        Rectangle {
                            anchors.fill: parent
                            radius: 8
                            color: index === root.selected
                                   ? Qt.alpha(Kirigami.Theme.highlightColor, 0.30)
                                   : (catItem.containsMouse ? Qt.alpha(Kirigami.Theme.textColor, 0.08) : "transparent")
                        }
                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: Kirigami.Units.smallSpacing * 2
                            anchors.rightMargin: Kirigami.Units.smallSpacing
                            spacing: Kirigami.Units.smallSpacing * 2
                            Kirigami.Icon {
                                source: model.decoration
                                Layout.preferredWidth: Kirigami.Units.iconSizes.smallMedium
                                Layout.preferredHeight: Kirigami.Units.iconSizes.smallMedium
                            }
                            PlasmaComponents3.Label {
                                Layout.fillWidth: true
                                text: model.display
                                elide: Text.ElideRight
                            }
                        }
                    }
                }

                Kirigami.Separator {
                    visible: cats.visible
                    Layout.fillHeight: true
                }

                // Auto-fitting app grid
                GridView {
                    id: grid
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    model: root.activeModel
                    keyNavigationEnabled: true

                    readonly property int iconSize: Plasmoid.configuration.iconSize
                    readonly property int minCell: iconSize + Kirigami.Units.gridUnit * 3
                    readonly property int cols: Math.max(1, Math.floor(width / minCell))
                    cellWidth: Math.floor(width / cols)
                    cellHeight: iconSize + Kirigami.Units.gridUnit * 3

                    Keys.onReturnPressed: root.launch(root.activeModel, currentIndex)
                    Keys.onEnterPressed: root.launch(root.activeModel, currentIndex)
                    Keys.onUpPressed: (event) => {
                        if (currentIndex < cols) searchField.forceActiveFocus()
                        else event.accepted = false
                    }

                    PlasmaComponents3.ScrollBar.vertical: PlasmaComponents3.ScrollBar {}

                    delegate: MouseArea {
                        id: tile
                        width: grid.cellWidth
                        height: grid.cellHeight
                        hoverEnabled: true
                        onClicked: root.launch(root.activeModel, index)

                        Rectangle {
                            anchors.fill: parent
                            anchors.margins: 4
                            radius: 10
                            color: (tile.containsMouse || (GridView.isCurrentItem && grid.activeFocus))
                                   ? Qt.alpha(Kirigami.Theme.highlightColor, 0.25)
                                   : "transparent"
                        }
                        ColumnLayout {
                            anchors.fill: parent
                            anchors.margins: Kirigami.Units.smallSpacing * 2
                            spacing: Kirigami.Units.smallSpacing
                            Item { Layout.fillHeight: true }
                            Kirigami.Icon {
                                Layout.alignment: Qt.AlignHCenter
                                Layout.preferredWidth: grid.iconSize
                                Layout.preferredHeight: grid.iconSize
                                source: model.decoration
                            }
                            PlasmaComponents3.Label {
                                Layout.fillWidth: true
                                horizontalAlignment: Text.AlignHCenter
                                text: model.display
                                elide: Text.ElideRight
                                maximumLineCount: 2
                                wrapMode: Text.Wrap
                            }
                            Item { Layout.fillHeight: true }
                        }
                    }

                    PlasmaComponents3.Label {
                        anchors.centerIn: parent
                        visible: grid.count === 0 && root.query.length > 0
                        opacity: 0.6
                        text: i18n("No results for “%1”", root.query)
                    }
                }
            }

            // Footer: power buttons (isolated so a missing module can't break the menu)
            RowLayout {
                Layout.fillWidth: true
                PlasmaComponents3.Label {
                    opacity: 0.6
                    text: "Noru"
                    font.bold: true
                }
                Item { Layout.fillWidth: true }
                Loader { source: "PowerBar.qml" }
            }
        }
    }
}
