import QtQuick
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami
import org.kcmutils as KCM

KCM.SimpleKCM {
    property alias cfg_iconSize: iconSpin.value
    property alias cfg_showSidebar: sidebarCheck.checked

    Kirigami.FormLayout {
        QQC2.SpinBox {
            id: iconSpin
            Kirigami.FormData.label: i18n("App icon size:")
            from: 32; to: 128; stepSize: 8
        }
        QQC2.CheckBox {
            id: sidebarCheck
            Kirigami.FormData.label: i18n("Mega menu:")
            text: i18n("Show category sidebar")
        }
    }
}
