#!/usr/bin/env bash
# Noru installer for KDE Plasma 6 (user-level)
set -euo pipefail
cd "$(dirname "$0")"
KPT=kpackagetool6
command -v $KPT >/dev/null || { echo "kpackagetool6 not found (Plasma 6 required)"; exit 1; }
ID=org.noru.launcher

case "${1:-install}" in
  install)
    $KPT --type Plasma/Applet --upgrade ./plasmoid 2>/dev/null || $KPT --type Plasma/Applet --install ./plasmoid
    echo "Installed. Right-click the panel -> Add Widgets -> Noru"
    echo "Or run: $0 add-to-panel"
    ;;
  add-to-panel)
    qdbus6 org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript '
      var ps = panels();
      if (ps.length > 0) {
        var p = ps[0], found = false;
        for (var i = 0; i < p.widgetIds.length; i++)
          if (p.widgetById(p.widgetIds[i]).type == "'$ID'") found = true;
        if (!found) p.addWidget("'$ID'");
      }'
    echo "Added to the first panel. Drag it where you want in panel edit mode."
    ;;
  uninstall)
    $KPT --type Plasma/Applet --remove $ID || true
    echo "Removed."
    ;;
  *) echo "usage: $0 [install|add-to-panel|uninstall]"; exit 1;;
esac
